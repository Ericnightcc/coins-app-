import http from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {randomBytes,randomUUID,scryptSync,timingSafeEqual,createHash} from 'node:crypto';
import {mkdirSync,readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
import {validateCoin,ensure,inventoryCsv,compsCsv} from './domain.mjs';
import {createRecovery,recoveryMailFromEnvironment} from './recovery.mjs';
import {createBilling,googlePlayFromEnvironment} from './billing.mjs';
const root=fileURLToPath(new URL('.',import.meta.url));
export function createApp({dataDir=process.env.DATA_DIR||join(root,'data'),origin=process.env.PUBLIC_ORIGIN||'http://localhost:8080',sendRecovery=recoveryMailFromEnvironment(),play=googlePlayFromEnvironment()}={}) {
 mkdirSync(dataDir,{recursive:true});
 const db=new DatabaseSync(join(dataDir,'inventory.sqlite')); db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA secure_delete=ON;');
 db.exec(`CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,salt TEXT NOT NULL,hash TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id) ON DELETE CASCADE,expires INTEGER);
 CREATE TABLE IF NOT EXISTS coins(id TEXT NOT NULL,user_id TEXT REFERENCES users(id) ON DELETE CASCADE,body TEXT NOT NULL,PRIMARY KEY(user_id,id));`);
 const attempts=new Map();
 const recovery=createRecovery(db,origin,sendRecovery);
 const billing=createBilling(db,play);
 const hash=t=>createHash('sha256').update(t).digest('hex');
 function json(res,status,value,headers={}) {res.writeHead(status,{'Content-Type':'application/json',...headers});res.end(JSON.stringify(value));}
 function list(uid){return db.prepare('SELECT body FROM coins WHERE user_id=? ORDER BY rowid DESC').all(uid).map(r=>JSON.parse(r.body));}
 async function body(req){let size=0,chunks=[];for await(const chunk of req){size+=chunk.length;if(size>9_000_000)throw Object.assign(new Error('Upload too large. Use smaller photos.'),{status:413});chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks));}catch{throw Object.assign(new Error('Invalid JSON'),{status:400});}}
 const server=http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data: blob:; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  try {
   const path=new URL(req.url,origin).pathname;
   if(!['GET','HEAD'].includes(req.method)&&req.headers.origin&&req.headers.origin!==origin) return json(res,403,{error:'Origin not allowed'});
   if(path==='/api/health')return json(res,200,{ok:true});
   if(path==='/eric-night-logo.png'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'image/png'});return res.end(readFileSync(join(root,'public','eric-night-logo.png')));}
   if(['/api/register','/api/login','/api/recovery/request','/api/recovery/reset'].includes(path)){
    ensure(req.method==='POST','Use POST');
    const k=req.socket.remoteAddress;const now=Date.now();let a=attempts.get(k);if(!a||now-a.start>600000){a={start:now,count:0};attempts.set(k,a);} if(++a.count>30)return json(res,429,{error:'Too many attempts. Try again in 10 minutes.'});
    if(attempts.size>10000)for(const [key,value] of attempts)if(now-value.start>600000)attempts.delete(key);
    const v=await body(req);
    if(path==='/api/recovery/request'){recovery.request(v.email);return json(res,200,{message:'If an account matches, a reset email will arrive shortly. Check spam too.'});}
    if(path==='/api/recovery/reset'){recovery.reset(v.token,v.password);return json(res,200,{message:'Password changed. Sign in again on each device.'},{'Set-Cookie':'session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});}
    const email=String(v.email||'').trim().toLowerCase();ensure(email.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),'Enter a valid email');
    ensure(typeof v.password==='string'&&v.password.length>=12&&v.password.length<=128,'Use a password between 12 and 128 characters');
    let user=db.prepare('SELECT * FROM users WHERE email=?').get(email);
    if(path==='/api/register'){
     if(user)return json(res,409,{error:'Account unavailable. Try signing in.'});
     const salt=randomBytes(16).toString('hex');user={id:randomUUID(),email,salt,hash:scryptSync(v.password,salt,64).toString('hex')};
     db.prepare('INSERT INTO users VALUES(?,?,?,?)').run(user.id,email,salt,user.hash);
    }else{
     const calculated=scryptSync(v.password,user?.salt||'dummy-auth-salt',64);
     if(!user||!timingSafeEqual(calculated,Buffer.from(user.hash,'hex')))return json(res,401,{error:'Email or password is incorrect'});
    }
    const token=randomBytes(32).toString('hex');db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hash(token),user.id,Date.now()+7*86400000);
    return json(res,200,{id:user.id,email:user.email},{'Set-Cookie':`session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800${origin.startsWith('https:')?'; Secure':''}`});
   }
   if(path.startsWith('/api/')){
    const token=(req.headers.cookie||'').match(/(?:^|;\s*)session=([a-f0-9]{64})(?:;|$)/)?.[1];
    const user=token&&db.prepare('SELECT users.id,users.email FROM sessions JOIN users ON users.id=sessions.user_id WHERE token=? AND expires>?').get(hash(token),Date.now());
    if(!user)return json(res,401,{error:'Sign in to access your private inventory'});
    if(path==='/api/me'&&req.method==='GET')return json(res,200,user);
    if(path==='/api/billing/config'&&req.method==='GET')return json(res,200,billing.config(user.id));
    if(path==='/api/billing/status'&&req.method==='GET')return json(res,200,await billing.status(user.id));
    if(path==='/api/billing/verify'&&req.method==='POST'){const value=await body(req);return json(res,200,await billing.verify(user.id,value.token));}
    if(path==='/api/logout'&&req.method==='POST'){db.prepare('DELETE FROM sessions WHERE token=?').run(hash(token));return json(res,200,{ok:true},{'Set-Cookie':'session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});}
    if(path==='/api/account'&&req.method==='DELETE'){
     const v=await body(req);const u=db.prepare('SELECT * FROM users WHERE id=?').get(user.id);
     ensure(typeof v.password==='string'&&v.password.length<=128&&timingSafeEqual(scryptSync(v.password,u.salt,64),Buffer.from(u.hash,'hex')),'Incorrect password');
     db.prepare('DELETE FROM users WHERE id=?').run(user.id);db.exec('PRAGMA wal_checkpoint(TRUNCATE)');return json(res,200,{ok:true},{'Set-Cookie':'session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});
    }
    if(path==='/api/coins'&&req.method==='GET')return json(res,200,list(user.id).map(({front,back,...c})=>c));
    if(path==='/api/coins'&&req.method==='POST'){
     const c=validateCoin(await body(req));const prior=db.prepare('SELECT body FROM coins WHERE user_id=? AND id=?').get(user.id,c.id);
     if(prior)return json(res,200,{id:c.id,duplicate:true});
     if(!(await billing.status(user.id)).active)return json(res,402,{error:'An active subscription is required to save new coins. Existing inventory and exports remain available.'});
     ensure(db.prepare('SELECT COUNT(*) AS n FROM coins WHERE user_id=?').get(user.id).n<1000,'Prototype inventory limit is 1,000 coins per account');
     c.createdAt=new Date().toISOString();db.prepare('INSERT INTO coins VALUES(?,?,?)').run(c.id,user.id,JSON.stringify(c));return json(res,201,{id:c.id});
    }
    const m=path.match(/^\/api\/coins\/([a-f0-9-]{36})(?:\/photo\/(front|back))?$/i);
    if(m){const row=db.prepare('SELECT body FROM coins WHERE user_id=? AND id=?').get(user.id,m[1]);if(!row)return json(res,404,{error:'Coin not found'});const c=JSON.parse(row.body);
     if(req.method==='DELETE'&&!m[2]){db.prepare('DELETE FROM coins WHERE user_id=? AND id=?').run(user.id,m[1]);return json(res,200,{ok:true});}
     if(req.method==='GET'&&m[2]){const [meta,b64]=c[m[2]].split(',');res.writeHead(200,{'Content-Type':meta.slice(5,-7)});return res.end(Buffer.from(b64,'base64'));}
     if(req.method==='GET')return json(res,200,c);
    }
    if((path==='/api/export/inventory.csv'||path==='/api/export/comps.csv')&&req.method==='GET'){
     res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':`attachment; filename="${path.endsWith('comps.csv')?'sold-comparables':'coin-inventory'}.csv"`});return res.end(path.endsWith('comps.csv')?compsCsv(list(user.id)):inventoryCsv(list(user.id),origin));
    }
    return json(res,404,{error:'Not found'});
   }
   const assets={'/':'index.html','/app.js':'app.js','/billing-ui.js':'billing-ui.js','/style.css':'style.css','/privacy':'privacy.html','/delete-account':'index.html','/recover':'recover.html','/recover.js':'recover.js'};
   if(!assets[path]||req.method!=='GET')return json(res,404,{error:'Not found'});
   const ext=assets[path].split('.').pop();res.writeHead(200,{'Content-Type':{html:'text/html; charset=utf-8',js:'text/javascript; charset=utf-8',css:'text/css; charset=utf-8'}[ext]});res.end(readFileSync(join(root,'public',assets[path])));
  }catch(e){if(!res.headersSent)json(res,e.status||500,{error:e.status?e.message:'Server error. Please retry.'});else res.end();if(!e.status)console.error(e);}
 });
 server.on('close',()=>db.close());return {server,db};
}
if(process.argv[1]&&fileURLToPath(import.meta.url)===process.argv[1]){
 if(process.env.NODE_ENV==='production'&&!/^https:\/\//.test(process.env.PUBLIC_ORIGIN||''))throw new Error('Set PUBLIC_ORIGIN to the public HTTPS origin before production startup');
 const {server}=createApp();server.listen(Number(process.env.PORT||8080),process.env.HOST||'127.0.0.1',()=>console.log(`Coin Ledger running at ${process.env.PUBLIC_ORIGIN||'http://localhost:8080'}`));
}
