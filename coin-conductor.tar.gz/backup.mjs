import {DatabaseSync,backup} from 'node:sqlite';
import {mkdir,rename,rm,stat} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';

// Use SQLite's online backup API so committed WAL records are included.
export async function backupInventory(source, destinationDirectory) {
 await stat(source); // Never silently create an empty source database.
 await mkdir(destinationDirectory,{recursive:true,mode:0o700});
 const name=`inventory-${new Date().toISOString().replace(/[:.]/g,'-')}-${randomUUID()}.sqlite`;
 const target=join(destinationDirectory,name),temporary=target+'.partial';
 const db=new DatabaseSync(source,{readOnly:true});
 try {
  await backup(db,temporary);
  const check=new DatabaseSync(temporary);
  try {
   if(check.prepare('PRAGMA integrity_check').get().integrity_check!=='ok')throw new Error('Backup integrity check failed');
   for(const table of ['users','sessions','coins'])check.prepare(`SELECT COUNT(*) FROM ${table}`).get();
   // A restore requires fresh sign-in; old sessions must not be reactivated.
   check.exec('PRAGMA secure_delete=ON; DELETE FROM sessions; PRAGMA wal_checkpoint(TRUNCATE);');
   if(check.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='password_resets'").get())check.exec('DELETE FROM password_resets; PRAGMA wal_checkpoint(TRUNCATE);');
  }finally{check.close();}
  await rename(temporary,target);
  return target;
 }catch(error){await rm(temporary,{force:true});throw error;}
 finally{db.close();}
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [source,destination]=process.argv.slice(2);
 if(!source||!destination)throw new Error('Usage: node backup.mjs <inventory.sqlite> <private-backup-directory>');
 console.log(await backupInventory(resolve(source),resolve(destination)));
}
