import {createHash,createSign} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {ensure} from './domain.mjs';
export const accountId=id=>createHash('sha256').update('coin-ledger:'+id).digest('hex');
const unavailable=()=>Object.assign(new Error('Subscription verification is unavailable. Please retry.'),{status:503});

export function googlePlayFromEnvironment(){
 const mode=process.env.BILLING_MODE||'pilot';
 if(mode==='pilot')return null;
 if(mode!=='play')throw new Error('BILLING_MODE must be pilot or play');
 const packageName=process.env.PLAY_PACKAGE_NAME,productId=process.env.PLAY_PRODUCT_ID,basePlanId=process.env.PLAY_BASE_PLAN_ID;
 if(!packageName||!productId||!basePlanId||!process.env.PLAY_SERVICE_ACCOUNT_FILE)throw new Error('Play billing requires package, product, base plan and a private service-account file');
 const credentials=JSON.parse(readFileSync(process.env.PLAY_SERVICE_ACCOUNT_FILE,'utf8'));
 if(!credentials.client_email||!credentials.private_key)throw new Error('Invalid Play service-account configuration');
 let cached=null,inflight=null;
 async function accessToken(){
  if(cached&&cached.expires>Date.now()+60000)return cached.token;
  if(inflight)return inflight;
  inflight=(async()=>{
   const now=Math.floor(Date.now()/1000),enc=v=>Buffer.from(JSON.stringify(v)).toString('base64url');
   const unsigned=enc({alg:'RS256',typ:'JWT'})+'.'+enc({iss:credentials.client_email,scope:'https://www.googleapis.com/auth/androidpublisher',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600});
   const signature=createSign('RSA-SHA256').update(unsigned).sign(credentials.private_key,'base64url');
   const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',signal:AbortSignal.timeout(15000),headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion:unsigned+'.'+signature})});
   if(!response.ok)throw unavailable();const data=await response.json();
   if(typeof data.access_token!=='string'||!Number.isFinite(data.expires_in))throw unavailable();
   cached={token:data.access_token,expires:Date.now()+data.expires_in*1000};return cached.token;
  })().finally(()=>{inflight=null;});return inflight;
 }
 async function call(path,method='GET'){
  try{
   const response=await fetch('https://androidpublisher.googleapis.com/androidpublisher/v3/applications/'+encodeURIComponent(packageName)+path,{method,signal:AbortSignal.timeout(15000),headers:{Authorization:'Bearer '+await accessToken(),'Content-Type':'application/json'},...(method==='POST'?{body:'{}'}:{})});
   if(response.status===404||response.status===410)throw Object.assign(new Error('Subscription not found. Restore purchases from the purchasing Google account.'),{status:400});
   if(!response.ok)throw unavailable();return method==='GET'?await response.json():null;
  }catch(error){if(error.status)throw error;throw unavailable();}
 }
 return {packageName,productId,basePlanId,
  get:token=>call('/purchases/subscriptionsv2/tokens/'+encodeURIComponent(token)),
  acknowledge:token=>call('/purchases/subscriptions/'+encodeURIComponent(productId)+'/tokens/'+encodeURIComponent(token)+':acknowledge','POST')};
}

export function subscriptionAccess(purchase,productId,basePlanId,now=Date.now()){
 const line=purchase.lineItems?.find(item=>item.productId===productId&&item.offerDetails?.basePlanId===basePlanId);
 const expires=Date.parse(line?.expiryTime),state=purchase.subscriptionState;
 const active=!!line&&Number.isFinite(expires)&&expires>now&&['SUBSCRIPTION_STATE_ACTIVE','SUBSCRIPTION_STATE_IN_GRACE_PERIOD','SUBSCRIPTION_STATE_CANCELED'].includes(state);
 return {active,expiresAt:Number.isFinite(expires)?new Date(expires).toISOString():null,state:state||'UNKNOWN'};
}

export function createBilling(db,play){
 db.exec('CREATE TABLE IF NOT EXISTS subscriptions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,verified_at INTEGER NOT NULL);');
 async function verify(uid,token){
  if(!play)throw Object.assign(new Error('Subscriptions are not enabled for this pilot.'),{status:503});
  ensure(typeof token==='string'&&token.length>=10&&token.length<=4096,'Invalid purchase token');
  const existing=db.prepare('SELECT user_id FROM subscriptions WHERE token=?').get(token);
  ensure(!existing||existing.user_id===uid,'This purchase belongs to another account');
  const purchase=await play.get(token);
  ensure(purchase.externalAccountIdentifiers?.obfuscatedExternalAccountId===accountId(uid),'Use the Coin Ledger account that purchased this subscription');
  ensure(purchase.lineItems?.some(item=>item.productId===play.productId&&item.offerDetails?.basePlanId===play.basePlanId),'Subscription product does not match');
  const result=subscriptionAccess(purchase,play.productId,play.basePlanId);
  if(result.active&&purchase.acknowledgementState==='ACKNOWLEDGEMENT_STATE_PENDING')await play.acknowledge(token);
  // Google ownership binding plus the unique token prevents cross-account claiming.
  db.prepare('INSERT INTO subscriptions VALUES(?,?,?) ON CONFLICT(token) DO UPDATE SET verified_at=excluded.verified_at WHERE subscriptions.user_id=excluded.user_id').run(token,uid,Date.now());
  return result;
 }
 return {verify,
  config(uid){return {mode:play?'play':'pilot',accountId:accountId(uid),productId:play?.productId,basePlanId:play?.basePlanId};},
  async status(uid){
   if(!play)return {mode:'pilot',active:true,state:'FREE_PILOT'};
   const rows=db.prepare('SELECT token FROM subscriptions WHERE user_id=? ORDER BY verified_at DESC').all(uid);
   let result={active:false,state:'NO_SUBSCRIPTION',expiresAt:null};
   for(const row of rows){try{result=await verify(uid,row.token);if(result.active)break;}catch(error){if(error.status!==400)throw error;}}
   return {mode:'play',...result};
  }
 };
}
