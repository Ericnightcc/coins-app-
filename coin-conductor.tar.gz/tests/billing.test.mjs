import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {createBilling,accountId,subscriptionAccess} from '../billing.mjs';
import {createApp} from '../server.mjs';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
const purchase=(uid,patch={})=>({externalAccountIdentifiers:{obfuscatedExternalAccountId:accountId(uid)},subscriptionState:'SUBSCRIPTION_STATE_ACTIVE',acknowledgementState:'ACKNOWLEDGEMENT_STATE_PENDING',lineItems:[{productId:'monthly',offerDetails:{basePlanId:'monthly-base'},expiryTime:new Date(Date.now()+86400000).toISOString()}],...patch});

test('access follows Google state, exact product/base plan and expiry',()=>{
 for(const state of ['ACTIVE','IN_GRACE_PERIOD','CANCELED'])assert.equal(subscriptionAccess(purchase('a',{subscriptionState:'SUBSCRIPTION_STATE_'+state}),'monthly','monthly-base').active,true);
 for(const state of ['PENDING','ON_HOLD','PAUSED','EXPIRED','PENDING_PURCHASE_CANCELED','UNSPECIFIED'])assert.equal(subscriptionAccess(purchase('a',{subscriptionState:'SUBSCRIPTION_STATE_'+state}),'monthly','monthly-base').active,false);
 const p=purchase('a');p.lineItems[0].expiryTime='2000-01-01T00:00:00Z';assert.equal(subscriptionAccess(p,'monthly','monthly-base').active,false);
 p.lineItems[0].expiryTime='invalid';assert.equal(subscriptionAccess(p,'monthly','monthly-base').active,false);
 assert.equal(subscriptionAccess(purchase('a'),'other','monthly-base').active,false);
 assert.equal(subscriptionAccess(purchase('a'),'monthly','other').active,false);
});

test('tokens bind to owner, acknowledge only verified active purchases, and refresh state',async()=>{
 const db=new DatabaseSync(':memory:');db.exec("PRAGMA foreign_keys=ON; CREATE TABLE users(id TEXT PRIMARY KEY); INSERT INTO users VALUES('a'),('b');");
 let value=purchase('a'),acks=0,calls=0;
 const play={productId:'monthly',basePlanId:'monthly-base',get:async()=>{calls++;return value;},acknowledge:async()=>{acks++;value={...value,acknowledgementState:'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED'};}};
 const billing=createBilling(db,play),token='synthetic-token-1';
 try{
  assert.equal((await billing.status('a')).active,false);
  await assert.rejects(billing.verify('b',token),/account/);
  assert.equal(acks,0);
  assert.equal((await billing.verify('a',token)).active,true);assert.equal(acks,1);
  assert.equal((await billing.verify('a',token)).active,true);assert.equal(acks,1);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM subscriptions').get().n,1);
  await assert.rejects(billing.verify('b',token),/another account/);
  value={...value,subscriptionState:'SUBSCRIPTION_STATE_ON_HOLD'};
  assert.equal((await billing.status('a')).active,false);
  value={...value,subscriptionState:'SUBSCRIPTION_STATE_CANCELED'};
  assert.equal((await billing.status('a')).active,true);
  value.lineItems[0].expiryTime='2000-01-01T00:00:00Z';assert.equal((await billing.status('a')).active,false);
  play.get=async()=>{throw Object.assign(new Error('Unavailable'),{status:503});};
  await assert.rejects(billing.status('a'),/Unavailable/);
  assert.ok(calls>=5);db.prepare('DELETE FROM users WHERE id=?').run('a');assert.equal(db.prepare('SELECT COUNT(*) AS n FROM subscriptions').get().n,0);
 }finally{db.close();}
});

test('pilot mode is explicit and cannot accept purchase claims',async()=>{
 const db=new DatabaseSync(':memory:');db.exec('CREATE TABLE users(id TEXT PRIMARY KEY);');
 try{const billing=createBilling(db,null);assert.equal(billing.config('a').mode,'pilot');assert.equal((await billing.status('a')).state,'FREE_PILOT');await assert.rejects(billing.verify('a','synthetic-token'),/not enabled/);}finally{db.close();}
});

test('paid API gates new saves, preserves reads and exports, and rejects unauthenticated claims',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'coin-paid-test-'));let value;
 const play={productId:'monthly',basePlanId:'monthly-base',get:async()=>value,acknowledge:async()=>{value.acknowledgementState='ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED';}};
 const app=createApp({dataDir:dir,play,sendRecovery:null});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
 const url='http://127.0.0.1:'+app.server.address().port;let cookie='';
 const request=async(path,method='GET',body)=>fetch(url+'/api/'+path,{method,headers:{cookie,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});
 try{
  assert.equal((await request('billing/verify','POST',{token:'synthetic-token'})).status,401);
  const registered=await request('register','POST',{email:'paid@example.test',password:'synthetic-password-123'});cookie=registered.headers.get('set-cookie').split(';')[0];const user=await registered.json();value=purchase(user.id);
  const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jZ1kAAAAASUVORK5CYII=';
  const coin={id:randomUUID(),country:'US',confirmed:true,purchased:true,year:1881,mint:'S',series:'Morgan dollar',denomination:'$1',service:'PCGS',grade:'MS65',cert:'TEST',sticker:'None',front:image,back:image,purchasePrice:'1.00',purchaseDate:'2026-01-01',comps:[]};
  assert.equal((await request('coins','POST',coin)).status,402);
  assert.equal((await request('billing/verify','POST',{token:'synthetic-token'})).status,200);
  assert.equal((await request('coins','POST',coin)).status,201);
  value.subscriptionState='SUBSCRIPTION_STATE_EXPIRED';
  assert.equal((await request('coins','POST',{...coin,id:randomUUID()})).status,402);
  assert.equal((await request('coins')).status,200);
  assert.equal((await request('export/inventory.csv')).status,200);
  assert.equal((await request('coins/'+coin.id+'/photo/front')).status,200);
  assert.equal((await request('coins','POST',coin)).status,200);
 }finally{await new Promise(r=>app.server.close(r));await rm(dir,{recursive:true,force:true});}
});
