import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,readFile,writeFile,readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomBytes} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {encryptedBackup,decryptBackup} from '../encrypted-backup.mjs';

test('encrypted backup restores photos, rejects tampering and wrong keys, and never overwrites',async()=>{
 const root=await mkdtemp(join(tmpdir(),'cc-encrypted-test-'));
 const db=new DatabaseSync(join(root,'live.sqlite'));
 const key=randomBytes(32).toString('hex');
 try{
  db.exec("PRAGMA journal_mode=WAL; CREATE TABLE users(id TEXT); CREATE TABLE sessions(token TEXT); CREATE TABLE coins(body TEXT); INSERT INTO users VALUES('owner'); INSERT INTO sessions VALUES('session-secret');");
  const record=JSON.stringify({front:'synthetic front',back:'synthetic back',purchaseCents:123});
  db.prepare('INSERT INTO coins VALUES(?)').run(record);
  const encrypted=await encryptedBackup(join(root,'live.sqlite'),join(root,'backups'),key);
  const bytes=await readFile(encrypted);assert.equal(bytes.includes(Buffer.from('synthetic front')),false);
  const restored=await decryptBackup(encrypted,join(root,'restore'),key);
  const check=new DatabaseSync(restored,{readOnly:true});
  try{assert.equal(check.prepare('SELECT body FROM coins').get().body,record);assert.equal(check.prepare('SELECT COUNT(*) AS n FROM sessions').get().n,0);assert.equal(check.prepare('PRAGMA integrity_check').get().integrity_check,'ok');}finally{check.close();}
  await assert.rejects(decryptBackup(encrypted,join(root,'restore'),key));
  await assert.rejects(decryptBackup(encrypted,join(root,'wrong-key'),randomBytes(32).toString('hex')));
  bytes[25]^=1;await writeFile(join(root,'tampered'),bytes);
  await assert.rejects(decryptBackup(join(root,'tampered'),join(root,'tampered-restore'),key));
  const names=await readdir(root);assert.ok(!names.includes('wrong-key'));assert.ok(!names.includes('tampered-restore'));
  assert.equal((await readdir(join(root,'backups'))).length,1);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n,1);
 }finally{db.close();await rm(root,{recursive:true,force:true});}
});
