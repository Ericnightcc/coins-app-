import test from 'node:test';
import assert from 'node:assert/strict';
import {recoveryMailFromEnvironment} from '../recovery.mjs';

test('recovery uses verified sender and owner reply address without sending real mail',async()=>{
 const names=['RESEND_API_KEY','RECOVERY_FROM','RECOVERY_REPLY_TO'];
 const previous=names.map(name=>process.env[name]);const originalFetch=globalThis.fetch;
 try{
  delete process.env.RESEND_API_KEY;delete process.env.RECOVERY_FROM;
  assert.equal(recoveryMailFromEnvironment(),null);
  process.env.RESEND_API_KEY='synthetic-key';process.env.RECOVERY_FROM='Coin Conductor <reset@verified.example>';
  delete process.env.RECOVERY_REPLY_TO;
  let payload;
  globalThis.fetch=async(url,options)=>{assert.equal(url,'https://api.resend.com/emails');payload=JSON.parse(options.body);return {ok:true};};
  await recoveryMailFromEnvironment()({email:'test@example.com',url:'https://app.example/recover#token=synthetic'});
  assert.equal(payload.from,'Coin Conductor <reset@verified.example>');
  assert.equal(payload.reply_to,'ericnightcc@gmail.com');assert.deepEqual(payload.to,['test@example.com']);
  process.env.RECOVERY_REPLY_TO='other@example.com';
  await recoveryMailFromEnvironment()({email:'test@example.com',url:'https://app.example/recover#token=synthetic'});
  assert.equal(payload.reply_to,'other@example.com');
 }finally{
  globalThis.fetch=originalFetch;
  names.forEach((name,i)=>{if(previous[i]===undefined)delete process.env[name];else process.env[name]=previous[i];});
 }
});
