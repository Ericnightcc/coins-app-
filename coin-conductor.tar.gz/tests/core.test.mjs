import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {createApp} from '../server.mjs';
import {validateCoin,csv,cents} from '../domain.mjs';
const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jZ1kAAAAASUVORK5CYII=';
const coin=()=>({id:randomUUID(),country:'US',confirmed:true,purchased:true,year:1881,mint:'S',series:'Morgan dollar',denomination:'$1',service:'PCGS',grade:'MS65',cert:'TEST-123',designations:'PL',sticker:'Green',front:image,back:image,purchasePrice:'123.45',purchaseDate:'2026-01-01',notes:'TEST ONLY',comps:[{source:'eBay',url:'https://www.ebay.com/itm/123456789012',title:'SYNTHETIC TEST FIXTURE — not a real sale',soldDate:'2026-01-01',amount:'150.75',basis:'Item price',matchNotes:'Synthetic fixture only; same grade',soldConfirmed:true}]});
test('amounts preserve cents, blank is unknown, and invalid amounts fail',()=>{assert.equal(cents('123.45'),12345);assert.equal(cents('',true),null);for(const v of ['-1','NaN','1e5','2.222',{},Infinity])assert.throws(()=>cents(v));});
test('coin confirmation, country, service, sticker, photos and sold-only validation',()=>{
 for(const service of ['PCGS','NGC','ICG','ANACS','CAC'])assert.equal(validateCoin({...coin(),service,sticker:'None'}).service,service);
 for(const grade of ['PF55','PR4','AU58','MS65+','UNC DETAILS'])assert.equal(validateCoin({...coin(),grade}).grade,grade);
 for(const grade of ['AU99','MS4','VF65','PF99'])assert.throws(()=>validateCoin({...coin(),grade}));
 for(const patch of [{confirmed:false},{purchased:false},{purchaseDate:''},{purchasePrice:''},{country:'CA'},{service:'Other'},{service:'CAC',sticker:'Green'},{front:''},{grade:'99'},{year:1500},{back:'data:image/png;base64,YWJjZA=='}])assert.throws(()=>validateCoin({...coin(),...patch}));
 for(const patch of [{soldConfirmed:false},{url:'https://evil.example/sale'},{url:'https://ebay.com.evil.example/sale'},{url:'javascript:alert(1)'},{soldDate:'2026-02-30'},{soldDate:'2099-01-01'},{basis:'Asking price'},{matchNotes:''}]){const c=coin();Object.assign(c.comps[0],patch);assert.throws(()=>validateCoin(c));}
 const c=coin();c.comps.push(c.comps[0]);assert.throws(()=>validateCoin(c));
});
test('CSV escapes quotes and prevents formulas',()=>{const s=csv([['=HYPERLINK("bad")','  @SUM(A1)','hello, "world"']]);assert.ok(s.includes("'=HYPERLINK"));assert.ok(s.includes("'  @SUM"));assert.ok(s.includes('"hello, ""world"""'));});
test('API round trip, private photos, independent tenants, idempotency, exports and deletion',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'coin-ledger-test-'));let app=createApp({dataDir:dir});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));let base='http://127.0.0.1:'+app.server.address().port;
 const call=async(path,{cookie='',method='GET',body,origin}={})=>{const r=await fetch(base+'/api/'+path,{method,headers:{cookie,'Content-Type':'application/json',...(origin?{Origin:origin}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:r.status,cookie:r.headers.get('set-cookie')?.split(';')[0],type:r.headers.get('content-type'),text:await r.text()};};
 try{
  assert.equal((await call('coins')).status,401);
  const a=await call('register',{method:'POST',body:{email:'a@test.example',password:'twelve-characters-A'}});assert.equal(a.status,200);
  const b=await call('register',{method:'POST',body:{email:'b@test.example',password:'twelve-characters-B'}});assert.equal(b.status,200);
  const record=coin();assert.equal((await call('coins',{cookie:a.cookie,method:'POST',body:record,origin:'https://evil.example'})).status,403);
  assert.equal((await call('coins',{cookie:a.cookie,method:'POST',body:{...record,confirmed:false}})).status,400);
  assert.equal((await call('coins',{cookie:a.cookie,method:'POST',body:record})).status,201);
  assert.equal((await call('coins',{cookie:a.cookie,method:'POST',body:record})).status,200);
  assert.equal(JSON.parse((await call('coins',{cookie:a.cookie})).text).length,1);
  assert.equal(JSON.parse((await call('coins',{cookie:b.cookie})).text).length,0);
  for(const path of ['coins/'+record.id,'coins/'+record.id+'/photo/front'])assert.equal((await call(path,{cookie:b.cookie})).status,404);
  assert.equal((await call('coins/'+record.id,{cookie:b.cookie,method:'DELETE'})).status,404);
  const photo=await call('coins/'+record.id+'/photo/front',{cookie:a.cookie});assert.equal(photo.status,200);assert.equal(photo.type,'image/png');
  const inv=await call('export/inventory.csv',{cookie:a.cookie});assert.equal(inv.status,200);assert.ok(inv.text.includes('123.45'));assert.ok(inv.text.includes(record.id));
  const cmp=await call('export/comps.csv',{cookie:a.cookie});assert.ok(cmp.text.includes('150.75'));assert.ok(cmp.text.includes('User-confirmed'));assert.ok(!(await call('export/inventory.csv',{cookie:b.cookie})).text.includes(record.id));
  await new Promise(r=>app.server.close(r));app=createApp({dataDir:dir});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));base='http://127.0.0.1:'+app.server.address().port;
  const saved=JSON.parse((await call('coins/'+record.id,{cookie:a.cookie})).text);assert.equal(saved.front,image);assert.equal(saved.purchaseCents,12345);assert.equal(saved.comps[0].amountCents,15075);
  assert.equal((await call('account',{cookie:a.cookie,method:'DELETE',body:{password:'wrong'}})).status,400);
  assert.equal((await call('account',{cookie:a.cookie,method:'DELETE',body:{password:'twelve-characters-A'}})).status,200);
  assert.equal((await call('me',{cookie:a.cookie})).status,401);
  assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM coins').get().n,0);
  assert.equal((await call('me',{cookie:b.cookie})).status,200);
  await call('logout',{cookie:b.cookie,method:'POST',body:{}});assert.equal((await call('me',{cookie:b.cookie})).status,401);
 }finally{await new Promise(r=>app.server.close(r));rmSync(dir,{recursive:true,force:true});}
});
