import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,stat} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {backupInventory} from '../backup.mjs';

test('online backup restores committed WAL data and photos, clears sessions, preserves live data',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'coin-backup-'));
 const source=join(dir,'inventory.sqlite');const db=new DatabaseSync(source);
 try {
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA wal_autocheckpoint=0;
   CREATE TABLE users(id TEXT PRIMARY KEY,email TEXT,salt TEXT,hash TEXT);
   CREATE TABLE sessions(token TEXT PRIMARY KEY,user_id TEXT,expires INTEGER);
   CREATE TABLE coins(id TEXT,user_id TEXT,body TEXT);
   INSERT INTO users VALUES('a','test@example.test','salt','hash');
   INSERT INTO sessions VALUES('old-session','a',9999999999999);`);
  const record={front:'synthetic-front-photo',back:'synthetic-back-photo',purchasePrice:12345};
  db.prepare('INSERT INTO coins VALUES(?,?,?)').run('coin','a',JSON.stringify(record));
  assert.ok((await stat(source+'-wal')).size>0);
  const result=await backupInventory(source,join(dir,'copies'));
  const restored=new DatabaseSync(result);
  try {
   assert.deepEqual(JSON.parse(restored.prepare('SELECT body FROM coins').get().body),record);
   assert.equal(restored.prepare('SELECT COUNT(*) AS n FROM users').get().n,1);
   assert.equal(restored.prepare('SELECT COUNT(*) AS n FROM sessions').get().n,0);
   assert.equal(restored.prepare('PRAGMA integrity_check').get().integrity_check,'ok');
  }finally{restored.close();}
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n,1);
  assert.notEqual(await backupInventory(source,join(dir,'copies')),result);
  await assert.rejects(backupInventory(join(dir,'missing.sqlite'),join(dir,'copies')));
 }finally{db.close();await rm(dir,{recursive:true,force:true});}
});
