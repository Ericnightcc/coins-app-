import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createApp} from '../server.mjs';

test('recovery keeps responses private, uses expiring one-time secrets and invalidates sessions',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'coin-recovery-')),mail=[];
 const app=createApp({dataDir:dir,sendRecovery:async value=>mail.push(value)});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
 const url='http://127.0.0.1:'+app.server.address().port;
 const post=async(path,body,extra={})=>{
  const response=await fetch(url+'/api/'+path,{method:'POST',headers:{'Content-Type':'application/json',...extra},body:JSON.stringify(body)});
  return {status:response.status,body:await response.json(),cookie:response.headers.get('set-cookie')?.split(';')[0]};
 };
 try{
  const original={email:'owner@example.test',password:'old-test-password-123'};
  const account=await post('register',original);
  const known=await post('recovery/request',{email:original.email});
  const unknown=await post('recovery/request',{email:'missing@example.test'});
  assert.deepEqual(known.body,unknown.body);assert.equal(known.status,200);
  await new Promise(resolve=>setImmediate(resolve));assert.equal(mail.length,1);
  const link=new URL(mail[0].url),token=new URLSearchParams(link.hash.slice(1)).get('token');
  assert.equal(link.search,'');assert.equal(token.length,64);
  assert.notEqual(app.db.prepare('SELECT token FROM password_resets').get().token,token);
  await post('recovery/request',{email:original.email});assert.equal(mail.length,1);
  const password='new-test-password-456';
  assert.equal((await post('recovery/reset',{token,password},{Origin:'https://evil.example'})).status,403);
  assert.equal((await post('recovery/reset',{token,password:'short'})).status,400);
  assert.equal((await post('recovery/reset',{token:'0'.repeat(64),password})).status,400);
  assert.equal((await post('recovery/reset',{token,password})).status,200);
  assert.equal((await post('recovery/reset',{token,password})).status,400);
  assert.equal((await fetch(url+'/api/me',{headers:{Cookie:account.cookie}})).status,401);
  assert.equal((await post('login',original)).status,401);
  assert.equal((await post('login',{email:original.email,password})).status,200);
  const second={email:'second@example.test',password:'second-password-123'};
  await post('register',second);await post('recovery/request',{email:second.email});
  await new Promise(resolve=>setImmediate(resolve));
  const expired=new URLSearchParams(new URL(mail[1].url).hash.slice(1)).get('token');
  app.db.prepare('UPDATE password_resets SET expires=0').run();
  assert.equal((await post('recovery/reset',{token:expired,password})).status,400);
  assert.equal((await post('login',second)).status,200);
 }finally{await new Promise(resolve=>app.server.close(resolve));await rm(dir,{recursive:true,force:true});}
});

test('unconfigured email recovery returns an honest unavailable response',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'coin-recovery-off-'));const app=createApp({dataDir:dir,sendRecovery:null});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
 try{
  const response=await fetch('http://127.0.0.1:'+app.server.address().port+'/api/recovery/request',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:'a@example.test'})});
  assert.equal(response.status,503);
 }finally{await new Promise(resolve=>app.server.close(resolve));await rm(dir,{recursive:true,force:true});}
});
