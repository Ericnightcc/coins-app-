export const services = ['PCGS','NGC','ICG','ANACS','CAC'];
export function ensure(ok, message) { if (!ok) throw Object.assign(new Error(message), {status:400}); }
const str=(v,max=200)=>typeof v==='string'&&v.trim().length<=max?v.trim():'';
export function cents(v, optional=false) {
  if(optional&&(v===''||v===null||v===undefined)) return null;
  ensure(typeof v==='number'||typeof v==='string','Invalid amount');
  ensure(/^\d{1,9}(\.\d{1,2})?$/.test(String(v)), 'Enter a non-negative USD amount with at most two decimals');
  return Math.round(Number(v)*100);
}
export function date(v) {
  ensure(typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&!isNaN(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v&&v<=new Date().toISOString().slice(0,10),'Enter a valid date that is not in the future'); return v;
}
export function photo(v) {
  ensure(typeof v==='string'&&v.length<4200000&&/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(v),'Both photos must be JPEG, PNG, or WebP and under 3 MB');
  const b=Buffer.from(v.split(',')[1],'base64');
  ensure((v.startsWith('data:image/jpeg')&&b[0]===255&&b[1]===216)||(v.startsWith('data:image/png')&&b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))||(v.startsWith('data:image/webp')&&b.toString('ascii',0,4)==='RIFF'&&b.toString('ascii',8,12)==='WEBP'),'Invalid photo data'); return v;
}
export function validateCoin(v) {
  ensure(v&&typeof v==='object','Invalid coin');
  ensure(/^[a-f0-9-]{36}$/i.test(v.id),'Invalid inventory identifier');
  ensure(v.country==='US'&&v.confirmed===true,'Confirm this is a U.S. graded coin and verify the label');
  ensure(v.purchased===true,'Only purchased coins can be added to owned inventory');
  ensure(services.includes(v.service),'Unsupported grading service');
  const year=Number(v.year); ensure(Number.isInteger(year)&&year>=1792&&year<=new Date().getFullYear()+1,'Enter a valid U.S. coin year');
  const series=str(v.series,100), denomination=str(v.denomination,60), cert=str(v.cert,80), grade=str(v.grade,50).toUpperCase();
  ensure(series&&denomination&&cert&&grade,'Series, denomination, certification number, and grade are required');
  const numeric=grade.match(/^(MS|PR|PF|SP|PO|FR|AG|G|VG|F|VF|XF|EF|AU)\s?(\d{1,2})\+?$/);
  const scale={PO:[1],FR:[2],AG:[3],G:[4,6],VG:[8,10],F:[12,15],VF:[20,25,30,35],XF:[40,45],EF:[40,45],AU:[50,53,55,58],MS:Array.from({length:11},(_,i)=>60+i)};
  const proofNumbers=[1,2,3,4,6,8,10,12,15,20,25,30,35,40,45,50,53,55,58,...scale.MS];
  ensure((numeric&&(scale[numeric[1]]||proofNumbers).includes(Number(numeric[2])))||/^[A-Z ]*DETAILS(?:[A-Z ]*)?$/.test(grade),'Use a valid label grade such as MS65, PF55, AU58, or AU DETAILS');
  ensure(['None','Green','Gold','Unknown'].includes(v.sticker),'Invalid CAC sticker');
  ensure(v.service!=='CAC'||v.sticker==='None','CAC holders do not receive a separate CAC sticker');
  const comps=(Array.isArray(v.comps)?v.comps:[]); ensure(comps.length<=50,'Maximum 50 comps per coin');
  const normalized=comps.map(c=>{
    ensure(['eBay','Heritage Auctions','Collectors Corner'].includes(c.source),'Invalid comp source');
    let u; try{u=new URL(c.url);}catch{ensure(false,'Invalid source link');}
    const domain={'eBay':'ebay.com','Heritage Auctions':'ha.com','Collectors Corner':'collectorscorner.com'}[c.source];
    ensure(u.protocol==='https:'&&!u.username&&!u.password&&(u.hostname===domain||u.hostname.endsWith('.'+domain)),'Comp link must be HTTPS on the selected source domain');
    ensure(c.soldConfirmed===true,'Only confirmed actual sales can be recorded as sold comps');
    ensure(['Item price','Includes buyer premium','Hammer only','Unknown'].includes(c.basis),'Specify the price basis');
    ensure(str(c.title,250)&&str(c.matchNotes,500),'Record the comp title and differences from your coin');
    return {source:c.source,url:u.href,title:str(c.title,250),soldDate:date(c.soldDate),amountCents:cents(c.amount),basis:c.basis,matchNotes:str(c.matchNotes,500),verification:'User-confirmed sale; not independently verified',recordedAt:new Date().toISOString()};
  });
  ensure(new Set(normalized.map(c=>c.url)).size===normalized.length,'Duplicate comp source link');
  return {id:v.id,country:'US',year,series,denomination,mint:str(v.mint,20),service:v.service,grade,cert,designations:str(v.designations,200),sticker:v.sticker,purchased:true,purchaseCents:cents(v.purchasePrice),purchaseDate:date(v.purchaseDate),notes:str(v.notes,1000),confirmed:true,front:photo(v.front),back:photo(v.back),comps:normalized};
}
export function csv(rows) {
  return '\uFEFF'+rows.map(r=>r.map(v=>{let s=String(v??'');if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}).join(',')).join('\r\n')+'\r\n';
}
export function inventoryCsv(coins,origin) {
  return csv([['Inventory ID','Country','Year','Series','Denomination','Mint','Grading service','Grade','Certification','Designations','CAC sticker','Purchase USD','Purchase date','Saved UTC','Sold comp count','Front photo (sign in)','Back photo (sign in)','Notes'],...coins.map(c=>[c.id,'US',c.year,c.series,c.denomination,c.mint,c.service,c.grade,c.cert,c.designations,c.sticker,c.purchaseCents===null?'':(c.purchaseCents/100).toFixed(2),c.purchaseDate,c.createdAt,c.comps.length,`${origin}/api/coins/${c.id}/photo/front`,`${origin}/api/coins/${c.id}/photo/back`,c.notes])]);
}
export function compsCsv(coins) {return csv([['Inventory ID','Source','Title','Sold date','Amount USD','Price basis','Source link','Differences / match notes','Verification','Recorded UTC'],...coins.flatMap(c=>c.comps.map(s=>[c.id,s.source,s.title,s.soldDate,(s.amountCents/100).toFixed(2),s.basis,s.url,s.matchNotes,s.verification,s.recordedAt]))]);}
