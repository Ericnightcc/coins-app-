import {randomBytes,createHash,scryptSync} from 'node:crypto';
import {ensure} from './domain.mjs';
const digest=value=>createHash('sha256').update(value).digest('hex');

export function recoveryMailFromEnvironment(){
 const key=process.env.RESEND_API_KEY,from=process.env.RECOVERY_FROM;
 const replyTo=process.env.RECOVERY_REPLY_TO||'ericnightcc@gmail.com';
 if(!key||!from)return null;
 return async({email,url})=>{
  const response=await fetch('https://api.resend.com/emails',{
   method:'POST',signal:AbortSignal.timeout(15000),
   headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},
   body:JSON.stringify({from,to:[email],reply_to:replyTo,subject:'Reset your Eric Night’s Coin Conductor password',text:`A password reset was requested for your Eric Night’s Coin Conductor account. Open this link within 30 minutes:\n\n${url}\n\nIf you did not request this, ignore this email. Your password has not changed.`})
  });
  if(!response.ok)throw new Error('Recovery email delivery failed');
 };
}

export function createRecovery(db,origin,send){
 db.exec('CREATE TABLE IF NOT EXISTS password_resets(token TEXT PRIMARY KEY,user_id TEXT UNIQUE REFERENCES users(id) ON DELETE CASCADE,expires INTEGER NOT NULL);');
 const requests=new Map();
 return {
  request(email){
   ensure(typeof email==='string'&&email.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),'Enter a valid email');
   if(!send)throw Object.assign(new Error('Password recovery email is not configured yet.'),{status:503});
   email=email.trim().toLowerCase();const now=Date.now();
   for(const [key,time] of requests)if(now-time>600000)requests.delete(key);
   if(requests.has(email)||requests.size>=10000)return;
   requests.set(email,now);
   db.prepare('DELETE FROM password_resets WHERE expires<=?').run(now);
   const user=db.prepare('SELECT id FROM users WHERE email=?').get(email);
   if(!user)return;
   const token=randomBytes(32).toString('hex');
   db.prepare('INSERT OR REPLACE INTO password_resets VALUES(?,?,?)').run(digest(token),user.id,now+1800000);
   // Fragment keeps the secret out of server access logs and referrer URLs.
   const url=new URL('/recover',origin);url.hash='token='+token;
   // Return the same response before contacting the email provider for any account.
   setImmediate(()=>Promise.resolve().then(()=>send({email,url:url.href})).catch(()=>console.error('Password recovery email delivery failed. Check provider configuration.')));
  },
  reset(token,password){
   ensure(typeof token==='string'&&/^[a-f0-9]{64}$/.test(token),'Reset link is invalid or expired');
   ensure(typeof password==='string'&&password.length>=12&&password.length<=128,'Use a password between 12 and 128 characters');
   db.exec('BEGIN IMMEDIATE');
   try{
    const row=db.prepare('SELECT user_id FROM password_resets WHERE token=? AND expires>?').get(digest(token),Date.now());
    ensure(row,'Reset link is invalid or expired');
    const salt=randomBytes(16).toString('hex');
    db.prepare('UPDATE users SET salt=?,hash=? WHERE id=?').run(salt,scryptSync(password,salt,64).toString('hex'),row.user_id);
    db.prepare('DELETE FROM sessions WHERE user_id=?').run(row.user_id);
    db.prepare('DELETE FROM password_resets WHERE user_id=?').run(row.user_id);
    db.exec('COMMIT');
   }catch(error){db.exec('ROLLBACK');throw error;}
  }
 };
}
