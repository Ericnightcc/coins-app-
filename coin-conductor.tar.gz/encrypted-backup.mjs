import {createCipheriv,createDecipheriv,randomBytes,randomUUID} from 'node:crypto';
import {createReadStream,createWriteStream} from 'node:fs';
import {mkdir,mkdtemp,open,link,rm,stat} from 'node:fs/promises';
import {pipeline} from 'node:stream/promises';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {backupInventory} from './backup.mjs';

const magic=Buffer.from('CCBACK01');
function keyBytes(key){
 if(typeof key!=='string'||! /^[a-fA-F0-9]{64}$/.test(key))throw new Error('Supply a 32-byte backup key as 64 hexadecimal characters');
 return Buffer.from(key,'hex');
}

// Encrypt only a consistent, session-scrubbed SQLite backup, never a live DB file.
export async function encryptedBackup(source,directory,key){
 const secret=keyBytes(key);
 await mkdir(directory,{recursive:true,mode:0o700});
 const staging=await mkdtemp(join(directory,'.backup-staging-'));
 const target=join(directory,`inventory-${Date.now()}-${randomUUID()}.ccbackup`);
 try{
  const plain=await backupInventory(source,staging);
  const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',secret,iv);
  cipher.setAAD(magic);
  const partial=join(staging,'encrypted.partial');
  const handle=await open(partial,'wx',0o600);
  try{await handle.write(Buffer.concat([magic,iv]));}finally{await handle.close();}
  await pipeline(createReadStream(plain),cipher,createWriteStream(partial,{flags:'a'}));
  const tagHandle=await open(partial,'a');
  try{await tagHandle.write(cipher.getAuthTag());await tagHandle.sync();}finally{await tagHandle.close();}
  await link(partial,target); // Fail rather than overwrite an existing backup.
  return target;
 }finally{secret.fill(0);await rm(staging,{recursive:true,force:true});}
}

// Restore into a new, empty directory only. Never replace a running database.
export async function decryptBackup(source,newDirectory,key){
 const secret=keyBytes(key);
 let created=false;
 try{
  const size=(await stat(source)).size;
  if(size<37)throw new Error('Invalid encrypted backup');
  const handle=await open(source,'r');
  const header=Buffer.alloc(20),tag=Buffer.alloc(16);
  try{await handle.read(header,0,20,0);await handle.read(tag,0,16,size-16);}finally{await handle.close();}
  if(!header.subarray(0,8).equals(magic))throw new Error('Unsupported backup format');
  await mkdir(newDirectory,{mode:0o700});created=true;
  const partial=join(newDirectory,'inventory.sqlite.partial');
  const decipher=createDecipheriv('aes-256-gcm',secret,header.subarray(8));
  decipher.setAAD(magic);decipher.setAuthTag(tag);
  await pipeline(createReadStream(source,{start:20,end:size-17}),decipher,createWriteStream(partial,{flags:'wx',mode:0o600}));
  const target=join(newDirectory,'inventory.sqlite');
  await link(partial,target);await rm(partial);
  return target;
 }catch(error){if(created)await rm(newDirectory,{recursive:true,force:true});throw error;}
 finally{secret.fill(0);}
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [operation,source,destination]=process.argv.slice(2);
 if(!['backup','restore'].includes(operation)||!source||!destination)throw new Error('Usage: node encrypted-backup.mjs backup|restore <source> <destination-directory>');
 const action=operation==='backup'?encryptedBackup:decryptBackup;
 console.log(await action(resolve(source),resolve(destination),process.env.COIN_BACKUP_KEY));
}
