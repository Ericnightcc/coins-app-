const token=new URLSearchParams(location.hash.slice(1)).get('token');
history.replaceState(null,'','/recover');
const request=document.querySelector('#request'),reset=document.querySelector('#reset'),status=document.querySelector('#status');
if(token){request.hidden=true;reset.hidden=false;}
for(const form of [request,reset])form.onsubmit=async event=>{
 event.preventDefault();const button=form.querySelector('button');button.disabled=true;
 try{
  const fields=Object.fromEntries(new FormData(form));
  if(form===reset&&fields.password!==fields.confirm)throw new Error('Passwords do not match.');
  const response=await fetch('/api/recovery/'+(form===reset?'reset':'request'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form===reset?{token,password:fields.password}:{email:fields.email})});
  const result=await response.json();if(!response.ok)throw new Error(result.error||'Please try again.');
  status.textContent=result.message;
  if(form===reset){form.reset();form.hidden=true;}
 }catch(error){status.textContent=error.message;}finally{button.disabled=false;}
};
