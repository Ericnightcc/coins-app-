const billingPanel=document.createElement('section');billingPanel.className='panel';
billingPanel.innerHTML='<h2>Subscription</h2><p id="billingStatus" role="status"></p><div class="actions"><button id="subscribe" class="secondary" hidden>View monthly subscription</button><button id="restorePurchases" class="secondary" hidden>Restore purchases</button><a id="manageSubscription" class="button secondary" href="https://play.google.com/store/account/subscriptions" target="_blank" rel="noopener" hidden>Manage in Google Play</a></div>';
document.querySelector('#workspace').append(billingPanel);
async function refreshBilling(){
 try{
  const config=await api('billing/config');
  const status=await api('billing/status');
  document.querySelector('#subscribe').hidden=config.mode!=='play'||!window.AndroidBilling||status.active;
  document.querySelector('#restorePurchases').hidden=config.mode!=='play'||!window.AndroidBilling;
  document.querySelector('#manageSubscription').hidden=config.mode!=='play';
  document.querySelector('#billingStatus').textContent=config.mode==='pilot'?'Free pilot access. No subscription payment is being collected.':status.active?'Subscription access is active'+(status.expiresAt?' through '+new Date(status.expiresAt).toLocaleDateString():'')+'.':window.AndroidBilling?'Subscribe or restore a purchase to save new coins. Existing inventory and exports remain available.':'Use the Android app to subscribe or restore a purchase. Existing inventory and exports remain available here.';
 }catch(error){document.querySelector('#billingStatus').textContent=error.message;}
}
document.querySelector('#subscribe').onclick=safe(async()=>{
 const config=await api('billing/config');
 if(config.mode==='play'&&window.AndroidBilling)AndroidBilling.buy(config.productId,config.basePlanId,config.accountId);
});
document.querySelector('#restorePurchases').onclick=()=>{if(window.AndroidBilling)AndroidBilling.restore();};
window.onBillingMessage=message=>notice(message);
window.onPlayPurchase=token=>safe(async()=>{
 const status=await api('billing/verify',{method:'POST',body:JSON.stringify({token})});
 notice(status.active?'Subscription verified. You can save coins.':'Purchase checked. Subscription access is not active yet.');
 await refreshBilling();
})();
